#ifndef DEBUG_H_
#define DEBUG_H_

void uart_debug(char p);
void uart_debugs(char *p);

#endif
